<?php

namespace Durianpay\Api\Errors;

use Exception;

class SignatureVerificationError extends Exception
{
}