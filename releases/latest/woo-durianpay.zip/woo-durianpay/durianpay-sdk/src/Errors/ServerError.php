<?php

namespace Durianpay\Api\Errors;

class ServerError extends Error
{
}